export default class Entity<T>{
    id:T
}